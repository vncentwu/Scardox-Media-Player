package us.littley.musicplayer; //you will need to fix this line!

public class GetSongResources {
    static int[] getSongResources() {
        int[] songResources = new int[10];
        songResources[0] = R.raw.fur_elise;
        songResources[1] = R.raw.les_baricades_misterieuses;
        songResources[2] = R.raw.piano_sonata_k_310_mvt_1;
        songResources[3] = R.raw.piano_sonata_k_545_mvt_1;
        songResources[4] = R.raw.prelude_in_c_major_bwv_846a;
        songResources[5] = R.raw.prelude_in_c_minor;
        songResources[6] = R.raw.prelude_in_e_minor;
        songResources[7] = R.raw.rondo_from_piano_sonata_no_58;
        songResources[8] = R.raw.sonata_in_g_minor_mvt_1;
        songResources[9] = R.raw.the_entertainer_rag;
        return songResources;
    }
}
